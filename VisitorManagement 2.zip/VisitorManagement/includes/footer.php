    </div>
    <script>
        document.documentElement.classList.add('scroll-smooth');
    </script>
</body>
</html>
